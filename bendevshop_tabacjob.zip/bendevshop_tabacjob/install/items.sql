-- Items du job tabac (inventaire ESX classique : table `items`)
-- La table tabac_plants est créée toute seule au démarrage de la ressource.
-- Si tu utilises ox_inventory, ignore ce fichier et regarde ox_inventory.lua.

-- ESX Legacy (colonne weight)
INSERT INTO `items` (`name`, `label`, `weight`) VALUES
    ('feuille_tabac', 'Feuille de tabac',       20),
    ('tabac_fin',     'Tabac fin',              30),
    ('clope_fine',    'Cigarette fine',         10),
    ('paquet_clope',  'Paquet de cigarettes',  100)
ON DUPLICATE KEY UPDATE `label` = VALUES(`label`);

-- Ancien ESX (colonne limit) : utilise plutôt ceci
-- INSERT INTO `items` (`name`, `label`, `limit`) VALUES
--     ('feuille_tabac', 'Feuille de tabac',       100),
--     ('tabac_fin',     'Tabac fin',               100),
--     ('clope_fine',    'Cigarette fine',          100),
--     ('paquet_clope',  'Paquet de cigarettes',     50)
-- ON DUPLICATE KEY UPDATE `label` = VALUES(`label`);
