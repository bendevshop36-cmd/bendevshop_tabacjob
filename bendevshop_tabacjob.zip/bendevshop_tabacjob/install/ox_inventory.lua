-- À copier dans ox_inventory/data/items.lua, dans la table retournée.
-- Les images vont dans ox_inventory/web/images/ (feuille_tabac.png, etc.).

['feuille_tabac'] = {
    label = 'Feuille de tabac',
    weight = 20,
},

['tabac_fin'] = {
    label = 'Tabac fin',
    weight = 30,
},

['clope_fine'] = {
    label = 'Cigarette fine',
    weight = 10,
},

['paquet_clope'] = {
    label = 'Paquet de cigarettes',
    weight = 100,
},
