Config = {}

-- Général
Config.Locale            = 'fr'            -- fichier dans locales/ (fr, en)
Config.Notify            = 'nui'           -- 'nui' (intégré) | 'esx' | 'ox'
Config.AdminGroups       = { 'admin', 'superadmin' } -- groupes ESX pouvant utiliser /addplant et /delplant
Config.CheckDistance     = true            -- vérifie la distance côté serveur (OneSync obligatoire)
Config.MaxDistance       = 12.0
Config.PedStreamDistance = 80.0            -- distance d'apparition des PNJ
Config.CraftMaxQty       = 25              -- quantité max par transformation

-- Images des objets
-- Le fichier doit porter le nom de l'item (ex : paquet_clope.png)
-- Ordre de recherche : overrides, path, localPath, puis une icône par défaut
Config.Images = {
    -- chemin de ton inventaire (%s = nom de l'item) :
    --   ox_inventory     : 'nui://ox_inventory/web/images/%s.png'
    --   qs-inventory     : 'nui://qs-inventory/html/images/%s.png'
    --   esx_inventoryhud : 'nui://esx_inventoryhud/html/img/items/%s.png'
    path      = 'nui://ox_inventory/web/images/%s.png',

    -- dossier de secours, dans html/img/ de cette ressource
    localPath = 'img/%s.png',

    -- image différente pour un item précis
    -- ['paquet_clope'] = 'nui://ma_ressource/images/paquet.png',
    overrides = {}
}

-- Petit camion qui flotte au-dessus des points de location / retour
Config.Marker = {
    drawDistance   = 20.0,
    icon           = 39,                       -- 39 = camion, 36 = voiture
    iconSize       = vector3(0.5, 0.5, 0.5),
    iconHeight     = 0.5,
    floatAmplitude = 0.07,
    floatSpeed     = 2.0,
    color          = { r = 139, g = 92, b = 246, a = 200 }
}

-- Récolte
Config.Recolte = {
    item           = 'feuille_tabac',
    quantite       = 1,
    respawnDelay   = 10000,    -- délai avant que la plante soit à nouveau récoltable (ms)
    duree          = 2500,     -- durée de la récolte (ms)
    model          = 'prop_plant_fern_02a',
    distanceSuppr  = 5.0,      -- portée de /delplant
    distanceMax    = 6.0,      -- distance max (serveur) pour récolter
    alphaRecoltee  = 140,      -- opacité d'une plante récoltée (255 = opaque)
    fadeTime       = 700,      -- durée du fondu (ms)
    streamDistance = 80.0,     -- distance d'apparition des plantes

    blip = {
        -- coords   = vector3(0.0, 0.0, 0.0),  -- à décommenter pour fixer la position
        --                                      -- sinon le blip se place au centre des plantes
        sprite     = 496,
        color      = 81,
        scale      = 0.8,
        display    = 4,        -- 4 = carte + minimap, 2 = carte seule
        shortRange = true,     -- false = visible de partout
        label      = '~y~[Intérim]~s~ Récolte Tabac'
    }
}

-- Camion
Config.Camion = {
    model          = 'boxville',
    prix           = 200,        -- caution, rendue quand on ramène le camion
    duree          = 7200000,    -- 2h (ms)
    warpInTruck    = true,       -- met le joueur au volant
    retourDistance = 15.0,       -- distance max entre le camion et le point de retour

    spawnPos = vector4(2893.7249, 4655.3545, 48.8859, 197.1951),

    markerLouer  = { pos = vector3(2889.6758, 4654.2598, 48.5840), radius = 2.0 },
    markerRetour = { pos = vector3(2889.6758, 4654.2598, 48.5840), radius = 2.0 },

    blipCamion = { sprite = 477, color = 27, scale = 0.8, shortRange = false, label = 'Camion Tabac' },
    blipRetour = { sprite = 357, color = 27, scale = 0.8, label = 'Retour Camion Tabac' },

    -- appelé juste après l'apparition du camion : carburant, clés...
    onSpawn = function(veh, plate)
        Entity(veh).state:set('fuel', 100.0, true)
        -- exports['qs-vehiclekeys']:GiveKeys(plate, 'boxville', true)
    end
}

-- Transformation : feuilles -> tabac fin
Config.Transfo1 = {
    pedModel = 's_m_y_construct_01',
    pedPos   = vector4(1775.7495, 4602.2588, 37.6072, 188.6059),
    blip     = {
        coords     = vector3(1775.7495, 4602.2588, 37.6072),
        sprite     = 496,
        color      = 81,
        scale      = 0.8,
        display    = 4,
        shortRange = true,
        label      = '~y~[Intérim]~s~ Transformation Feuilles'
    },
    menu     = { title = 'Job Tabac', category = 'Transformation de tabac', icon = 'fa-solid fa-industry' },
    actions  = {
        {
            id     = 'transfo1',
            title  = 'Transformer feuilles → tabac fin',
            desc   = '3 feuilles = 1 tabac fin',
            icon   = 'fa-solid fa-industry',
            input  = { item = 'feuille_tabac', quantite = 3 },
            output = { item = 'tabac_fin',     quantite = 1 },
            duree  = 5000      -- par opération (multiplié par la quantité)
        }
    }
}

-- Roulage et paquets
-- Attention : ces coordonnées sont loin des autres points du job, à vérifier
Config.Transfo2Paquet = {
    pedModel = 's_m_y_construct_01',
    pedPos   = vector4(1773.5575, 4595.3286, 37.7668, 268.3071),
    blip     = {
        coords     = vector3(1773.5575, 4595.3286, 37.7668),
        sprite     = 496,
        color      = 81,
        scale      = 0.8,
        display    = 4,
        shortRange = true,
        label      = '~y~[Intérim]~s~ Roulage & Paquet'
    },
    menu     = { title = 'Job Tabac', category = 'Roulage', icon = 'fa-solid fa-cannabis' },
    actions  = {
        {
            id     = 'transfo2',
            title  = 'Rouler une cigarette fine',
            desc   = '1 tabac fin = 1 cigarette fine',
            icon   = 'fa-solid fa-cannabis',
            input  = { item = 'tabac_fin',  quantite = 1 },
            output = { item = 'clope_fine', quantite = 1 },
            duree  = 4000
        },
        {
            id     = 'paquet',
            title  = 'Faire un paquet de cigarettes',
            desc   = '8 cigarettes fines = 1 paquet',
            icon   = 'fa-solid fa-box',
            input  = { item = 'clope_fine',   quantite = 8 },
            output = { item = 'paquet_clope', quantite = 1 },
            duree  = 3000
        }
    }
}

-- Vente
Config.Vente = {
    pedModel    = 's_m_m_strvend_01',
    pedPos      = vector4(2869.5920, 4415.2109, 49.1196, 123.0142),
    blip        = {
        coords     = vector3(2869.5920, 4415.2109, 49.1196),
        sprite     = 496,
        color      = 81,
        scale      = 0.8,
        display    = 4,
        shortRange = true,
        label      = '~y~[Intérim]~s~ Vente Paquets Tabac'
    },
    item        = 'paquet_clope',
    prixUnite   = 350,
    maxParVente = 100000
}
