Locales = Locales or {}

Locales['en'] = {
    -- general
    erreur            = 'Something went wrong',
    trop_loin         = "You're too far away",
    occupe            = 'An action is already in progress',
    annule            = 'Action cancelled',
    inventaire_plein  = 'Inventory full',
    quantite_invalide = 'Invalid quantity',
    minutes           = '%d min',

    -- harvesting
    recolte_target    = 'Harvest a tobacco leaf',
    recolte_progress  = 'Harvesting',
    recolte_success   = 'You harvested %sx tobacco leaf(s)',
    deja_recoltee     = 'This plant has already been harvested',
    plante_occupee    = 'Someone is already harvesting this plant',

    -- truck
    camion_pas_assez    = 'You need $%s to rent the truck',
    camion_deja_loue    = 'You already have a rented truck',
    camion_loue_ok      = 'Truck rented for %s min. Drive safe!',
    camion_expire       = 'The truck rental has expired',
    camion_perdu        = 'Your truck is gone, the rental is cancelled',
    camion_rendu_ok     = 'Truck returned, $%s refunded',
    camion_pas_proche   = 'Bring the truck closer to the return point',
    camion_zone_occupee = 'The truck spawn area is blocked',
    camion_help_louer   = 'Press ~INPUT_CONTEXT~ to rent a truck',
    camion_help_rendre  = 'Press ~INPUT_CONTEXT~ to return the truck',

    camion_menu         = 'Truck rental',
    camion_categorie    = 'Truck',
    camion_tag_louer    = 'Rental',
    camion_tag_retour   = 'Return',
    camion_btn_louer    = 'Rent the truck',
    camion_btn_rendre   = 'Return the truck',
    camion_desc_louer   = 'Delivery truck for your job',
    camion_desc_rendre  = 'Get your deposit back right away',
    camion_duree        = 'Duration',
    camion_caution      = 'Deposit',
    camion_caution_val  = '$%d (refunded on return)',
    camion_retour       = 'Return',
    camion_retour_val   = 'Anytime',
    camion_temps_reste  = 'Time left',
    camion_rembourse    = 'Refund',

    -- processing
    transfo1_target   = 'Leaf processing',
    transfo2_target   = 'Rolling & packing',
    transfo_btn       = 'Start processing',
    transfo_manque    = 'You need %sx %s',
    transfo_progress  = 'Processing',
    transfo_ok        = 'You got %sx %s',
    transfo_annule    = 'Processing cancelled',

    -- selling
    vente_target      = 'Sell cigarette packs',
    vente_titre       = 'Cigarette buyer',
    vente_tag         = 'Sell',
    vente_categorie   = 'Shop',
    vente_defaut      = 'Pack of cigarettes',
    vente_aucun       = "You don't have any pack to sell",
    vente_pas_assez   = "You don't have that many packs",
    vente_ok          = 'You sold %s pack(s) for $%s',

    -- admin commands
    plant_added       = 'Plant added (ID: %s)',
    plant_removed     = 'Plant removed (ID: %s)',
    plant_not_found   = 'No plant nearby',
    plant_not_in_db   = 'Plant not found in the database',
    plant_no_perm     = "You don't have permission",

    -- interface (NUI)
    ui = {
        search        = 'Search an item',
        sortAsc       = 'Name (A-Z)',
        sortDesc      = 'Name (Z-A)',
        quit          = 'Quit',
        cancel        = 'Cancel',
        confirm       = 'Confirm',
        noItem        = 'No item',
        quantity      = 'Quantity',
        max           = 'Max',
        details       = 'Details',
        selectHint    = 'Select an item to see its details.',
        required      = 'Required: ',
        obtained      = 'Obtained: ',
        inStockOf     = 'In stock: ',
        inStock       = 'In stock',
        totalDuration = 'Total time',
        unitPrice     = 'Unit price',
        selectedQty   = 'Selected quantity',
        totalAmount   = 'Total amount',
        sell          = 'Sell: ',
        inProgress    = 'In progress…',
        numLocale     = 'en-US'
    }
}
