Locales = Locales or {}

Locales['fr'] = {
    -- général
    erreur            = 'Une erreur est survenue',
    trop_loin         = 'Tu es trop loin',
    occupe            = 'Une action est déjà en cours',
    annule            = 'Action annulée',
    inventaire_plein  = 'Inventaire plein',
    quantite_invalide = 'Quantité invalide',
    minutes           = '%d min',

    -- récolte
    recolte_target    = 'Récolter une feuille de tabac',
    recolte_progress  = 'Récolte en cours',
    recolte_success   = 'Tu as récolté %sx feuille(s) de tabac',
    deja_recoltee     = 'Cette plante est déjà récoltée',
    plante_occupee    = "Quelqu'un récolte déjà cette plante",

    -- camion
    camion_pas_assez    = 'Il te faut %s$ pour louer le camion',
    camion_deja_loue    = 'Tu as déjà un camion loué',
    camion_loue_ok      = 'Camion loué pour %s min. Bonne route !',
    camion_expire       = 'La location du camion a expiré',
    camion_perdu        = 'Ton camion a disparu, la location est annulée',
    camion_rendu_ok     = 'Camion rendu, %s$ remboursés',
    camion_pas_proche   = 'Rapproche le camion du point de retour',
    camion_zone_occupee = 'La zone de sortie du camion est occupée',
    camion_help_louer   = 'Appuie sur ~INPUT_CONTEXT~ pour louer un camion',
    camion_help_rendre  = 'Appuie sur ~INPUT_CONTEXT~ pour rendre le camion',

    camion_menu         = 'Location de camion',
    camion_categorie    = 'Camion',
    camion_tag_louer    = 'Location',
    camion_tag_retour   = 'Retour',
    camion_btn_louer    = 'Louer le camion',
    camion_btn_rendre   = 'Rendre le camion',
    camion_desc_louer   = 'Camion de livraison pour ton job',
    camion_desc_rendre  = 'Récupère ta caution immédiatement',
    camion_duree        = 'Durée',
    camion_caution      = 'Caution',
    camion_caution_val  = '%d$ (remboursée au retour)',
    camion_retour       = 'Retour',
    camion_retour_val   = 'À tout moment',
    camion_temps_reste  = 'Temps restant',
    camion_rembourse    = 'Remboursement',

    -- transformation
    transfo1_target   = 'Transformation Feuilles',
    transfo2_target   = 'Roulage & Paquet',
    transfo_btn       = 'Lancer la transformation',
    transfo_manque    = 'Il te faut %sx %s',
    transfo_progress  = 'Transformation en cours',
    transfo_ok        = 'Tu as obtenu %sx %s',
    transfo_annule    = 'Transformation annulée',

    -- vente
    vente_target      = 'Vendre les paquets de tabac',
    vente_titre       = 'Rachat de cigarettes',
    vente_tag         = 'Vente',
    vente_categorie   = 'Boutique',
    vente_defaut      = 'Paquet de cigarettes',
    vente_aucun       = "Tu n'as aucun paquet à vendre",
    vente_pas_assez   = "Tu n'as pas autant de paquets",
    vente_ok          = 'Tu as vendu %s paquet(s) pour %s$',

    -- commandes admin
    plant_added       = 'Plante ajoutée (ID : %s)',
    plant_removed     = 'Plante supprimée (ID : %s)',
    plant_not_found   = 'Aucune plante à proximité',
    plant_not_in_db   = 'Plante introuvable en base de données',
    plant_no_perm     = "Tu n'as pas la permission",

    -- interface (NUI)
    ui = {
        search        = 'Rechercher un article',
        sortAsc       = 'Nom (A-Z)',
        sortDesc      = 'Nom (Z-A)',
        quit          = 'Quitter',
        cancel        = 'Annuler',
        confirm       = 'Confirmer',
        noItem        = 'Aucun article',
        quantity      = 'Quantité',
        max           = 'Max',
        details       = 'Détails',
        selectHint    = 'Sélectionne un élément pour voir les détails.',
        required      = 'Requis : ',
        obtained      = 'Obtenu : ',
        inStockOf     = 'En stock : ',
        inStock       = 'En stock',
        totalDuration = 'Durée totale',
        unitPrice     = 'Prix unitaire',
        selectedQty   = 'Quantité sélectionnée',
        totalAmount   = 'Montant total',
        sell          = 'Vendre : ',
        inProgress    = 'En cours…',
        numLocale     = 'fr-FR'
    }
}
