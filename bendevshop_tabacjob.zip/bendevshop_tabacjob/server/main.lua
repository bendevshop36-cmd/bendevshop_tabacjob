local ESX = exports['es_extended']:getSharedObject()

math.randomseed(os.time())

-- utilitaires

local function canCarry(xPlayer, item, count)
    if xPlayer.canCarryItem then return xPlayer.canCarryItem(item, count) end

    -- anciennes versions d'ESX : on regarde la limite à la main
    local inv = xPlayer.getInventoryItem(item)
    if not inv then return false end
    if inv.limit and inv.limit ~= -1 and inv.count + count > inv.limit then return false end
    return true
end

local function isAdmin(source, xPlayer)
    local group = xPlayer.getGroup()
    for _, allowed in ipairs(Config.AdminGroups) do
        if group == allowed then return true end
    end
    return IsPlayerAceAllowed(source, 'command')
end

local function isNear(source, pos, maxDist)
    if not Config.CheckDistance then return true end

    local ped = GetPlayerPed(source)
    if not ped or ped == 0 then return false end

    local target = vector3(pos.x, pos.y, pos.z)
    return #(GetEntityCoords(ped) - target) <= (maxDist or Config.MaxDistance)
end

local function itemLabel(xPlayer, item)
    local inv = xPlayer.getInventoryItem(item)
    return inv and inv.label or item
end

-- entier entre min et max, sinon nil (refuse les décimaux, NaN, négatifs...)
local function validQty(qty, min, max)
    qty = tonumber(qty)
    if not qty or qty ~= qty or qty ~= math.floor(qty) then return nil end
    if qty < min or qty > max then return nil end
    return qty
end

-- retire l'item puis vérifie combien ont vraiment disparu de l'inventaire
local function removeItem(xPlayer, item, count)
    local before = xPlayer.getInventoryItem(item)
    before = before and before.count or 0

    xPlayer.removeInventoryItem(item, count)

    local after = xPlayer.getInventoryItem(item)
    return before - (after and after.count or 0)
end

-- base de données

CreateThread(function()
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `tabac_plants` (
            `id`    INT NOT NULL AUTO_INCREMENT,
            `x`     DOUBLE NOT NULL,
            `y`     DOUBLE NOT NULL,
            `z`     DOUBLE NOT NULL,
            `model` VARCHAR(64) NOT NULL DEFAULT 'prop_plant_fern_02a',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ]])
end)

-- plantes

local plantsCache = {}  -- [id] = { x, y, z }
local cooldowns   = {}  -- [id] = fin du cooldown (GetGameTimer)
local reserved    = {}  -- [id] = { source, startedAt }

local RESERVE_TIMEOUT = 15000

local function getPlant(id)
    if plantsCache[id] then return plantsCache[id] end

    local row = MySQL.single.await('SELECT x, y, z FROM tabac_plants WHERE id = ?', { id })
    if row then plantsCache[id] = { x = row.x, y = row.y, z = row.z } end
    return plantsCache[id]
end

local function isOnCooldown(id)
    return cooldowns[id] ~= nil and cooldowns[id] > GetGameTimer()
end

lib.callback.register('tabac:chargerPlants', function()
    local rows = MySQL.query.await('SELECT id, x, y, z, model FROM tabac_plants') or {}
    local plants = {}

    plantsCache = {}
    for _, row in ipairs(rows) do
        plantsCache[row.id] = { x = row.x, y = row.y, z = row.z }
        plants[#plants + 1] = {
            id = row.id, x = row.x, y = row.y, z = row.z, model = row.model,
            recoltee = isOnCooldown(row.id)
        }
    end
    return plants
end)

lib.callback.register('tabac:ajouterPlant', function(source, x, y, z)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or not isAdmin(source, xPlayer) then return false end
    if type(x) ~= 'number' or type(y) ~= 'number' or type(z) ~= 'number' then return false end

    local id = MySQL.insert.await('INSERT INTO tabac_plants (x, y, z, model) VALUES (?, ?, ?, ?)',
        { x, y, z, Config.Recolte.model })
    if not id then return false end

    plantsCache[id] = { x = x, y = y, z = z }
    TriggerClientEvent('tabac:rechargerPlants', -1)
    return id
end)

lib.callback.register('tabac:supprimerPlant', function(source, id)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or not isAdmin(source, xPlayer) then return false, 'no_perm' end

    id = tonumber(id)
    if not id or not getPlant(id) then return false, 'not_found' end

    MySQL.query.await('DELETE FROM tabac_plants WHERE id = ?', { id })
    plantsCache[id], cooldowns[id], reserved[id] = nil, nil, nil
    TriggerClientEvent('tabac:rechargerPlants', -1)
    return true
end)

-- récolte en trois temps : début (réservation), fin (récompense), annulation

lib.callback.register('tabac:debutRecolte', function(source, id)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false, 'error' end

    id = tonumber(id)
    local plant = id and getPlant(id)
    if not plant then return false, 'error' end

    if not isNear(source, plant, Config.Recolte.distanceMax) then return false, 'trop_loin' end
    if isOnCooldown(id) then return false, 'deja_recoltee' end

    local res = reserved[id]
    if res and res.source ~= source and GetGameTimer() - res.startedAt < RESERVE_TIMEOUT then
        return false, 'occupee'
    end

    if not canCarry(xPlayer, Config.Recolte.item, Config.Recolte.quantite) then return false, 'full' end

    reserved[id] = { source = source, startedAt = GetGameTimer() }
    return true
end)

lib.callback.register('tabac:finRecolte', function(source, id)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false, 'error' end

    id = tonumber(id)
    local res = id and reserved[id]
    if not res or res.source ~= source then return false, 'error' end
    reserved[id] = nil

    -- le client ne peut pas finir plus vite que la durée de la récolte
    if GetGameTimer() - res.startedAt < Config.Recolte.duree - 500 then return false, 'error' end

    local plant = getPlant(id)
    if not plant then return false, 'error' end
    if not isNear(source, plant, Config.Recolte.distanceMax) then return false, 'trop_loin' end
    if isOnCooldown(id) then return false, 'deja_recoltee' end

    local qty = Config.Recolte.quantite
    if not canCarry(xPlayer, Config.Recolte.item, qty) then return false, 'full' end

    xPlayer.addInventoryItem(Config.Recolte.item, qty)

    local readyAt = GetGameTimer() + Config.Recolte.respawnDelay
    cooldowns[id] = readyAt
    TriggerClientEvent('tabac:masquerPlante', -1, id)

    SetTimeout(Config.Recolte.respawnDelay, function()
        -- si la plante a été supprimée entre temps, cooldowns[id] ne vaut plus readyAt
        if cooldowns[id] == readyAt then
            cooldowns[id] = nil
            TriggerClientEvent('tabac:montrerPlante', -1, id)
        end
    end)

    return true
end)

lib.callback.register('tabac:annulerRecolte', function(source, id)
    id = tonumber(id)
    if id and reserved[id] and reserved[id].source == source then reserved[id] = nil end
    return true
end)

-- camion (tout est en mémoire, rien en base)

local rentals = {}  -- [source] = { plate, expireAt, netId }

local function deleteTruck(netId)
    if not netId then return end

    local entity = NetworkGetEntityFromNetworkId(netId)
    if entity and entity ~= 0 and DoesEntityExist(entity) then
        DeleteEntity(entity)
    end
end

lib.callback.register('tabac:louerCamion', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false, 'error' end
    if not isNear(source, Config.Camion.markerLouer.pos) then return false, 'trop_loin' end

    local rental = rentals[source]
    if rental and rental.expireAt > os.time() then return false, 'deja_loue' end

    if xPlayer.getAccount('money').money < Config.Camion.prix then return false, 'pas_assez' end
    xPlayer.removeAccountMoney('money', Config.Camion.prix)

    local seconds = math.floor(Config.Camion.duree / 1000)
    local plate   = ('TABAC%03d'):format(math.random(0, 999))

    rentals[source] = { plate = plate, expireAt = os.time() + seconds }
    return true, seconds, plate
end)

-- le camion n'a pas pu apparaître : on rembourse (seulement s'il n'a jamais été enregistré)
lib.callback.register('tabac:annulerLocation', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    local rental = rentals[source]
    if not xPlayer or not rental or rental.netId then return false end

    rentals[source] = nil
    xPlayer.addAccountMoney('money', Config.Camion.prix)
    return true
end)

lib.callback.register('tabac:enregistrerCamion', function(source, netId)
    local rental = rentals[source]
    if not rental or type(netId) ~= 'number' then return false end

    rental.netId = netId
    return true
end)

lib.callback.register('tabac:retourCamion', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false, 'error' end

    local rental = rentals[source]
    if not rental then return false, 'error' end
    if not isNear(source, Config.Camion.markerRetour.pos) then return false, 'trop_loin' end

    if rental.expireAt < os.time() then
        deleteTruck(rental.netId)
        rentals[source] = nil
        return false, 'error'
    end

    -- le camion doit être près du point de retour
    if Config.CheckDistance and rental.netId then
        local entity = NetworkGetEntityFromNetworkId(rental.netId)
        if entity and entity ~= 0 and DoesEntityExist(entity) then
            local maxDist = Config.Camion.retourDistance + 5.0
            if #(GetEntityCoords(entity) - Config.Camion.markerRetour.pos) > maxDist then
                return false, 'camion_loin'
            end
        end
    end

    deleteTruck(rental.netId)
    rentals[source] = nil
    xPlayer.addAccountMoney('money', Config.Camion.prix)
    return true
end)

-- camion expiré ou détruit : on libère la location, sans remboursement
lib.callback.register('tabac:libererCamion', function(source)
    local rental = rentals[source]
    if rental then deleteTruck(rental.netId) end

    rentals[source] = nil
    return true
end)

-- transformation

local transfos       = {}  -- [id d'action] = { input, output, duree, pos }
local pendingTransfo = {}  -- [source] = { id, qty, startedAt, duration, expires }
local allowedItems   = { [Config.Recolte.item] = true, [Config.Vente.item] = true }

for _, station in ipairs({ Config.Transfo1, Config.Transfo2Paquet }) do
    for _, action in ipairs(station.actions) do
        transfos[action.id] = {
            input  = action.input,
            output = action.output,
            duree  = action.duree or 4000,
            pos    = station.pedPos
        }
        allowedItems[action.input.item]  = true
        allowedItems[action.output.item] = true
    end
end

-- stock du joueur pour les menus (seuls les items du job sont autorisés)
lib.callback.register('tabac:infosItems', function(source, names)
    local xPlayer = ESX.GetPlayerFromId(source)
    local result = {}
    if not xPlayer or type(names) ~= 'table' then return result end

    for i = 1, math.min(#names, 12) do
        local name = names[i]
        if type(name) == 'string' and allowedItems[name] and not result[name] then
            local inv = xPlayer.getInventoryItem(name)
            result[name] = { count = inv and inv.count or 0, label = inv and inv.label or name }
        end
    end
    return result
end)

lib.callback.register('tabac:debutTransfo', function(source, id, qty)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false, 'error' end

    local transfo = transfos[id]
    if not transfo then return false, 'error' end
    if not isNear(source, transfo.pos) then return false, 'trop_loin' end

    qty = validQty(qty, 1, Config.CraftMaxQty)
    if not qty then return false, 'quantite' end

    local pending = pendingTransfo[source]
    if pending and GetGameTimer() < pending.expires then return false, 'occupe' end

    local needed = transfo.input.quantite * qty
    local inv = xPlayer.getInventoryItem(transfo.input.item)
    if not inv or inv.count < needed then
        return false, 'manque', itemLabel(xPlayer, transfo.input.item), needed
    end

    if not canCarry(xPlayer, transfo.output.item, transfo.output.quantite * qty) then return false, 'full' end

    -- quantité et durée retenues ici, le client ne peut pas les changer à la fin
    local now      = GetGameTimer()
    local duration = transfo.duree * qty
    pendingTransfo[source] = {
        id = id, qty = qty, startedAt = now, duration = duration,
        expires = now + duration + 5000
    }
    return true
end)

lib.callback.register('tabac:finTransfo', function(source, id)
    local xPlayer = ESX.GetPlayerFromId(source)
    local pending = pendingTransfo[source]
    pendingTransfo[source] = nil
    if not xPlayer or not pending or pending.id ~= id then return false, 'error' end

    local transfo = transfos[id]
    if not transfo then return false, 'error' end

    if GetGameTimer() - pending.startedAt < pending.duration - 700 then return false, 'error' end
    if not isNear(source, transfo.pos) then return false, 'error' end

    local needed = transfo.input.quantite * pending.qty
    local outQty = transfo.output.quantite * pending.qty

    local inv = xPlayer.getInventoryItem(transfo.input.item)
    if not inv or inv.count < needed then return false, 'error' end
    if not canCarry(xPlayer, transfo.output.item, outQty) then return false, 'full' end

    -- on ne donne rien si les ingrédients n'ont pas vraiment été retirés
    if removeItem(xPlayer, transfo.input.item, needed) < needed then return false, 'error' end

    xPlayer.addInventoryItem(transfo.output.item, outQty)
    return true, itemLabel(xPlayer, transfo.output.item), outQty
end)

lib.callback.register('tabac:annulerTransfo', function(source)
    pendingTransfo[source] = nil
    return true
end)

-- vente (le prix vient toujours de la config serveur)

local selling = {}

local function sell(source, qty)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return 0, 0, 'error' end
    if not isNear(source, Config.Vente.pedPos) then return 0, 0, 'trop_loin' end

    qty = validQty(qty, 1, Config.Vente.maxParVente)
    if not qty then return 0, 0, 'quantite' end

    local inv = xPlayer.getInventoryItem(Config.Vente.item)
    if not inv or inv.count <= 0 then return 0, 0, 'manque' end
    if inv.count < qty then return 0, 0, 'pas_assez' end

    -- on ne paie que ce qui a réellement été retiré
    local removed = math.min(removeItem(xPlayer, Config.Vente.item, qty), qty)
    if removed <= 0 then return 0, 0, 'error' end

    local total = removed * Config.Vente.prixUnite
    xPlayer.addAccountMoney('money', total)
    return removed, total
end

lib.callback.register('tabac:vendre', function(source, qty)
    if selling[source] then return 0, 0, 'occupe' end

    selling[source] = true
    local ok, sold, total, err = pcall(sell, source, qty)
    selling[source] = nil

    if not ok then return 0, 0, 'error' end
    return sold, total, err
end)

-- nettoyage

AddEventHandler('playerDropped', function()
    local src = source

    local rental = rentals[src]
    if rental then deleteTruck(rental.netId) end

    rentals[src], pendingTransfo[src], selling[src] = nil, nil, nil

    for id, res in pairs(reserved) do
        if res.source == src then reserved[id] = nil end
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end

    for _, rental in pairs(rentals) do deleteTruck(rental.netId) end
end)
