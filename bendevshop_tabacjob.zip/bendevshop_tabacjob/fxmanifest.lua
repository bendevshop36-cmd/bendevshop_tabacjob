fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'bendev'
description 'Job tabac : récolte, transformation, vente (ESX)'
version '4.3.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    'locales/*.lua'
}

client_scripts {
    'client/utils.lua',
    'client/menu.lua',
    'client/recolte.lua',
    'client/camion.lua',
    'client/transformation.lua',
    'client/vente.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/logo.png',
    'html/img/*.png'
}

dependencies {
    'es_extended',
    'ox_lib',
    'ox_target',
    'oxmysql'
}
