const $ = (id) => document.getElementById(id);

const app        = $('app');
const menuTitle  = $('menu-title');
const tagBtn     = $('tag-btn');
const catIcon    = $('category-icon');
const catTitle   = $('category-title');
const toolbar    = $('toolbar');
const searchEl   = $('search-input');
const btnSort    = $('btn-sort');
const sortLabel  = $('sort-label');
const grid       = $('grid');
const sideTitle  = $('side-title');
const sideDesc   = $('side-desc');
const sideBody   = $('side-body');
const progressEl = $('progress');
const progLabel  = $('prog-label');
const progPct    = $('prog-pct');
const progTime   = $('prog-time');
const progBar    = $('prog-bar');
const btnCancel  = $('btn-cancel');
const btnMain    = $('btn-main');
const mainIcon   = $('main-icon');
const mainLabel  = $('main-label');
const btnQuit    = $('btn-quit');
const toasts     = $('toasts');
const quitLabel  = $('quit-label');

// textes par défaut, remplacés par locales/*.lua (clé ui) à l'ouverture du menu
const T = {
    search: 'Rechercher un article',
    sortAsc: 'Nom (A-Z)',
    sortDesc: 'Nom (Z-A)',
    quit: 'Quitter',
    cancel: 'Annuler',
    confirm: 'Confirmer',
    noItem: 'Aucun article',
    quantity: 'Quantité',
    max: 'Max',
    details: 'Détails',
    selectHint: 'Sélectionne un élément pour voir les détails.',
    required: 'Requis : ',
    obtained: 'Obtenu : ',
    inStockOf: 'En stock : ',
    inStock: 'En stock',
    totalDuration: 'Durée totale',
    unitPrice: 'Prix unitaire',
    selectedQty: 'Quantité sélectionnée',
    totalAmount: 'Montant total',
    sell: 'Vendre : ',
    inProgress: 'En cours…',
    numLocale: 'fr-FR'
};

const resourceName = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'tabac';

const state = {
    mode: 'action',
    items: [],
    selected: null,       // index Lua (1-based) de l'élément sélectionné
    qty: 1,               // quantité choisie (transformation / vente)
    keepOpen: false,
    buttonLabel: '',
    sortAsc: true,
    locked: false,
    lockToken: 0,
    raf: null
};

// Images
const IMG      = { path: '', localPath: '', overrides: {} };
const imgCache = {};   // nom d'item -> url qui fonctionne, ou false si introuvable

function imageSources(name) {
    const list = [];
    if (IMG.overrides[name]) list.push(IMG.overrides[name]);
    if (IMG.path)            list.push(IMG.path.replace('%s', name));
    if (IMG.localPath)       list.push(IMG.localPath.replace('%s', name));
    return list;
}

// Image de l'objet avec solution de remplacement (icône) si introuvable
function makeImg(name, fallbackIcon, cls) {
    const box = el('div', cls);

    const fallback = () => {
        box.innerHTML = '';
        box.classList.add('fallback');
        box.appendChild(icon(fallbackIcon || 'fa-solid fa-box'));
    };

    if (!name || imgCache[name] === false) { fallback(); return box; }

    const list = imgCache[name] ? [imgCache[name]] : imageSources(name);
    if (!list.length) { fallback(); return box; }

    const img = document.createElement('img');
    img.alt = '';
    img.draggable = false;

    let i = 0;
    img.addEventListener('load', () => { imgCache[name] = img.src; });
    img.addEventListener('error', () => {
        i++;
        if (i < list.length) {
            img.src = list[i];
        } else {
            imgCache[name] = false;
            fallback();
        }
    });
    img.src = list[0];

    box.appendChild(img);
    return box;
}

// Outils
function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
}
function icon(cls) { const i = document.createElement('i'); i.className = cls; return i; }
const money = (n) => '$' + Number(n || 0).toLocaleString(T.numLocale);

function fmtDur(ms) {
    const s = ms / 1000;
    if (s < 60) return (Math.round(s * 10) / 10) + ' s';
    const m = Math.floor(s / 60);
    const r = Math.round(s % 60);
    return m + ' min' + (r ? ' ' + r + ' s' : '');
}

function post(name, data) {
    return fetch(`https://${resourceName}/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(data || {})
    }).catch(() => {});
}

window.addEventListener('message', (event) => {
    const d = event.data;
    switch (d.action) {
        case 'openMenu':      openMenu(d); break;
        case 'updateMenu':    updateMenu(d); break;
        case 'closeMenu':     hideMenu(); break;
        case 'progressStart': startProgress(d); break;
        case 'progressEnd':   stopProgress(); break;
        case 'notify':        notify(d); break;
    }
});

function applyLang() {
    searchEl.placeholder = T.search;
    quitLabel.textContent = T.quit;
    btnCancel.textContent = T.cancel;
}

function normalize(list) {
    return (list || []).map((it, i) => ({
        index:    i + 1,
        id:       it.id !== undefined ? String(it.id) : String(i + 1),
        title:    it.title || '',
        desc:     it.desc || '',
        icon:     it.icon || 'fa-solid fa-box',
        image:    it.image,
        tag:      it.tag,
        price:    it.price,
        stock:    it.stock,
        max:      it.max,
        craft:    it.craft,
        details:  it.details || [],
        disabled: !!it.disabled,
        reason:   it.reason,
        button:   it.button
    }));
}

// Quantités
function itemMax(it) {
    if (it.craft) return Math.max(0, it.craft.max | 0);
    if (it.price !== undefined) {
        const m = Math.min(it.stock || 0, it.max ?? Infinity);
        return Number.isFinite(m) ? Math.max(0, m | 0) : 0;
    }
    return 0;
}

function hasQty(it) {
    return !!it && (!!it.craft || it.price !== undefined);
}

function clampQty(it, q) {
    const m = itemMax(it);
    if (m <= 0) return 0;
    q = parseInt(q, 10);
    if (!Number.isFinite(q)) q = 1;
    return Math.min(m, Math.max(1, q));
}

// Ouverture / fermeture
function openMenu(d) {
    state.mode        = d.mode === 'shop' ? 'shop' : 'action';
    state.keepOpen    = !!d.keepOpen;
    Object.assign(T, d.lang || {});
    applyLang();
    state.buttonLabel = d.buttonLabel || T.confirm;
    state.sortAsc     = true;
    state.qty         = 1;
    state.locked      = false;
    state.lockToken++;
    stopProgress(true);

    // Configuration des images
    const im = d.images || {};
    IMG.path      = im.path || '';
    IMG.localPath = im.localPath || '';
    IMG.overrides = (im.overrides && !Array.isArray(im.overrides)) ? im.overrides : {};

    menuTitle.textContent = d.title || '';
    searchEl.value = '';
    sortLabel.textContent = T.sortAsc;

    tagBtn.innerHTML = '';
    tagBtn.style.display = d.tag ? 'flex' : 'none';
    if (d.tag) {
        tagBtn.append(icon(d.tag.icon || 'fa-solid fa-store'), document.createTextNode(d.tag.title || ''));
    }

    const cat = d.category || {};
    catIcon.className = cat.icon || 'fa-solid fa-basket-shopping';
    catTitle.textContent = cat.title || '';

    state.items = normalize(d.items);
    state.selected = state.items.length === 1 ? state.items[0].index : null;

    toolbar.style.visibility = state.items.length > 1 ? 'visible' : 'hidden';

    renderAll();
    app.classList.remove('hidden');
    searchEl.blur();
}

function updateMenu(d) {
    state.items = normalize(d.items);
    if (!state.items.some(it => it.index === state.selected)) {
        state.selected = state.items.length === 1 ? state.items[0].index : null;
        state.qty = 1;
    }
    state.locked = false;
    state.lockToken++;
    stopProgress(true);
    toolbar.style.visibility = state.items.length > 1 ? 'visible' : 'hidden';
    renderAll();
}

function hideMenu() {
    app.classList.add('hidden');
    stopProgress(true);
    state.locked = false;
}

function closeMenu() {
    hideMenu();
    post('closeMenu');
}

// Rendu
function current() {
    return state.items.find(it => it.index === state.selected) || null;
}

function selectItem(index) {
    state.selected = index;
    state.qty = 1;
    renderAll();
}

function renderAll() {
    renderCards();
    renderSide();
    refreshControls();
}

function renderCards() {
    const q = searchEl.value.trim().toLowerCase();
    const list = state.items
        .filter(it => it.title.toLowerCase().includes(q))
        .sort((a, b) => state.sortAsc
            ? a.title.localeCompare(b.title, T.numLocale)
            : b.title.localeCompare(a.title, T.numLocale));

    grid.innerHTML = '';
    if (!list.length) {
        grid.appendChild(el('div', 'empty-msg', T.noItem));
        return;
    }

    list.forEach(it => {
        const selling = it.price !== undefined;
        const card = el('div', 'card');

        if (it.index === state.selected) card.classList.add('selected');
        if (hasQty(it) && itemMax(it) <= 0) card.classList.add('empty');

        // Haut de carte : prix (vente) ou ratio (transformation)
        card.appendChild(selling
            ? el('div', 'card-top', money(it.price))
            : el('div', 'card-top plain', it.tag || ''));

        // Badge de stock
        if (selling && it.stock !== undefined) card.appendChild(el('div', 'badge', 'x' + it.stock));
        else if (it.craft) card.appendChild(el('div', 'badge', 'x' + it.craft.output.have));

        // Image de l'objet (icône de secours si introuvable)
        card.appendChild(makeImg(it.image, it.icon, 'card-icon'));

        const name = el('div', 'card-name', selling ? '1 x ' + it.title : it.title);
        if (!selling && it.desc) name.appendChild(el('div', 'card-sub', it.desc));
        card.appendChild(name);

        card.addEventListener('click', () => {
            if (state.locked) return;
            selectItem(it.index);
        });

        grid.appendChild(card);
    });
}

function row(label, value, cls, imgName) {
    const r = el('div', 'row' + (cls === 'total' ? ' total' : ''));
    const left = el('span', 'row-left');
    if (imgName) left.appendChild(makeImg(imgName, 'fa-solid fa-box', 'row-img'));
    left.appendChild(document.createTextNode(label));
    r.append(left, el('span', (cls && cls !== 'total') ? cls : '', value));
    return r;
}

function buildQtyBlock(it, onChange) {
    const wrap = el('div', 'qty-block');
    wrap.appendChild(el('div', 'qty-label', T.quantity));

    const ctl   = el('div', 'qty-ctl');
    const minus = el('button', 'q-btn', '−');
    const plus  = el('button', 'q-btn', '+');
    const maxB  = el('button', 'q-max', T.max);

    const input = document.createElement('input');
    input.type = 'text';
    input.inputMode = 'numeric';
    input.autocomplete = 'off';
    input.maxLength = 4;
    input.className = 'q-input';
    input.value = String(state.qty);

    const apply = (q) => {
        state.qty = clampQty(it, q);
        input.value = String(state.qty);
        onChange();
    };

    minus.addEventListener('click', () => { if (!state.locked) apply(state.qty - 1); });
    plus.addEventListener('click',  () => { if (!state.locked) apply(state.qty + 1); });
    maxB.addEventListener('click',  () => { if (!state.locked) apply(itemMax(it)); });

    input.addEventListener('input', () => {
        if (state.locked) { input.value = String(state.qty); return; }
        input.value = input.value.replace(/\D/g, '');
        if (input.value === '') return;               // laisse l'utilisateur effacer pour retaper
        const q = clampQty(it, input.value);
        state.qty = q;
        if (String(q) !== input.value) input.value = String(q);
        onChange();
    });
    input.addEventListener('blur',  () => { input.value = String(state.qty); });
    input.addEventListener('focus', () => input.select());

    ctl.append(minus, input, plus, maxB);
    wrap.appendChild(ctl);
    return wrap;
}

function renderSide() {
    sideBody.innerHTML = '';
    sideDesc.textContent = '';

    const it = current();
    if (!it) {
        sideTitle.textContent = T.details;
        sideBody.appendChild(el('div', 'side-empty', T.selectHint));
        return;
    }

    sideTitle.textContent = it.title;
    sideDesc.textContent  = it.desc || '';

    // Éléments avec quantité (transformation / vente)
    if (hasQty(it)) {
        state.qty = clampQty(it, state.qty);
        if (state.qty === 0 && itemMax(it) > 0) state.qty = 1;

        const rows = el('div', 'rows');

        const fill = () => {
            rows.innerHTML = '';
            const q = Math.max(state.qty, 1);

            if (it.craft) {
                it.craft.inputs.forEach(inp => {
                    const need = inp.need * q;
                    rows.appendChild(row(T.required + inp.label, need + ' / ' + inp.have,
                        inp.have >= need ? 'ok' : 'bad', inp.item));
                });
                const out = it.craft.output;
                rows.appendChild(row(T.obtained + out.label, 'x' + (out.qty * q), 'ok', out.item));
                rows.appendChild(row(T.inStockOf + out.label, String(out.have)));
                rows.appendChild(row(T.totalDuration, fmtDur(it.craft.duration * q)));
            } else {
                rows.appendChild(row(T.unitPrice, money(it.price)));
                rows.appendChild(row(T.inStock, 'x' + (it.stock || 0)));
                rows.appendChild(row(T.selectedQty, 'x' + state.qty));
                rows.appendChild(row(T.totalAmount, money(it.price * state.qty), 'total'));
            }
        };

        if (itemMax(it) > 0) {
            sideBody.appendChild(buildQtyBlock(it, () => { fill(); refreshControls(); }));
        }
        sideBody.appendChild(rows);
        fill();

        if (itemMax(it) <= 0 && it.reason) {
            sideBody.appendChild(el('div', 'warn', it.reason));
        }
        return;
    }

    // Autres éléments (ex : camion) : détails statiques
    it.details.forEach(d => sideBody.appendChild(row(d.label, d.value, d.state, d.image)));
    if (it.disabled && it.reason) sideBody.appendChild(el('div', 'warn', it.reason));
}

function refreshControls() {
    const it = current();
    sideBody.classList.toggle('locked', state.locked);

    let label = state.buttonLabel;
    let ic = 'fa-solid fa-check';
    let disabled = state.locked || !it || it.disabled;

    if (it && it.price !== undefined) {
        ic = 'fa-solid fa-bag-shopping';
        label = T.sell + money(it.price * state.qty);
        disabled = state.locked || itemMax(it) <= 0 || state.qty <= 0;
    } else if (it && it.craft) {
        label = (it.button || state.buttonLabel) + (state.qty > 0 ? ' · x' + state.qty : '');
        disabled = state.locked || itemMax(it) <= 0 || state.qty <= 0;
    } else if (it && it.button) {
        label = it.button;
    }

    mainIcon.className = ic;
    mainLabel.textContent = label;
    btnMain.disabled = !!disabled;
}

// Validation
function lockTemp() {
    state.locked = true;
    const token = ++state.lockToken;
    refreshControls();
    // Sécurité : déverrouille si le serveur ne répond pas
    setTimeout(() => {
        if (state.lockToken === token && !state.raf) {
            state.locked = false;
            refreshControls();
        }
    }, 8000);
}

function confirmSelection() {
    if (btnMain.disabled || state.locked) return;

    const it = current();
    if (!it) return;

    const payload = { index: it.index };
    if (hasQty(it)) payload.qty = clampQty(it, state.qty);

    if (state.keepOpen) lockTemp();
    else hideMenu();

    post('selectAction', payload);
}

// Barre de progression
function startProgress({ duration, label }) {
    stopProgress(true);
    state.locked = true;
    state.lockToken++;

    progLabel.textContent = label || T.inProgress;
    progressEl.classList.remove('hidden');
    refreshControls();

    const start = performance.now();
    const total = Math.max(duration || 1, 1);

    const tick = (now) => {
        const t = Math.min((now - start) / total, 1);
        progBar.style.width = (t * 100).toFixed(1) + '%';
        progPct.textContent = Math.floor(t * 100) + '%';
        progTime.textContent = fmtDur(Math.max(0, total - (now - start)));
        if (t < 1) state.raf = requestAnimationFrame(tick);
        else state.raf = null;
    };
    state.raf = requestAnimationFrame(tick);
}

function stopProgress(silent) {
    if (state.raf) cancelAnimationFrame(state.raf);
    state.raf = null;
    progressEl.classList.add('hidden');
    progBar.style.width = '0%';
    progPct.textContent = '0%';
    if (!silent) {
        state.locked = false;
        refreshControls();
    }
}

// Évènements
searchEl.addEventListener('input', renderCards);

btnSort.addEventListener('click', () => {
    state.sortAsc = !state.sortAsc;
    sortLabel.textContent = state.sortAsc ? T.sortAsc : T.sortDesc;
    renderCards();
});

btnQuit.addEventListener('click', closeMenu);
btnMain.addEventListener('click', confirmSelection);
btnCancel.addEventListener('click', () => post('cancelProgress'));

document.addEventListener('keydown', (e) => {
    if (app.classList.contains('hidden')) return;
    if (e.key === 'Escape') closeMenu();
    if (e.key === 'Enter' && document.activeElement !== searchEl) confirmSelection();
});

// Notifications
const TOAST_ICONS = {
    success: 'fa-circle-check',
    error:   'fa-circle-xmark',
    info:    'fa-circle-info'
};

function notify({ message, type = 'info', duration = 4000 }) {
    const kind = TOAST_ICONS[type] ? type : 'info';

    const t = el('div', 'toast ' + kind);
    t.append(icon('fa-solid ' + TOAST_ICONS[kind]), el('span', null, message || ''));
    toasts.appendChild(t);

    requestAnimationFrame(() => requestAnimationFrame(() => t.classList.add('show')));

    setTimeout(() => {
        t.classList.remove('show');
        setTimeout(() => t.remove(), 300);
    }, duration);
}