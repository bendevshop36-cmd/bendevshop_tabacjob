local L, notify = Tabac.L, Tabac.notify

local busy = false
local lastOpen = 0

-- construit les cartes du menu avec le stock du joueur
local function buildItems(station)
    local names = {}
    for _, action in ipairs(station.actions) do
        names[#names + 1] = action.input.item
        names[#names + 1] = action.output.item
    end
    local stock = lib.callback.await('tabac:infosItems', false, names) or {}

    local items = {}
    for i, action in ipairs(station.actions) do
        local input  = stock[action.input.item]  or { count = 0, label = action.input.item }
        local output = stock[action.output.item] or { count = 0, label = action.output.item }
        local maxQty = math.min(math.floor(input.count / action.input.quantite), Config.CraftMaxQty)

        items[i] = {
            id    = action.id,
            title = action.title,
            desc  = action.desc,
            icon  = action.icon,
            image = action.output.item,
            tag   = ('%d → %d'):format(action.input.quantite, action.output.quantite),
            craft = {
                inputs   = { { item = action.input.item, label = input.label, have = input.count, need = action.input.quantite } },
                output   = { item = action.output.item, label = output.label, qty = action.output.quantite, have = output.count },
                duration = action.duree or 4000,
                max      = maxQty
            },
            disabled = maxQty < 1,
            reason   = maxQty < 1 and L('transfo_manque', action.input.quantite, input.label) or nil
        }
    end
    return items
end

local function refresh(station)
    if Tabac.isMenuOpen() then Tabac.updateMenu(buildItems(station)) end
end

local function transform(station, action, qty)
    if busy then return end

    qty = math.floor(tonumber(qty) or 0)
    if qty < 1 then return refresh(station) end

    busy = true

    local ok, err, label, needed = lib.callback.await('tabac:debutTransfo', false, action.id, qty)
    if not ok then
        if err == 'manque' then
            notify(L('transfo_manque', needed, label), 'error')
        else
            Tabac.notifyError(err)
        end
        busy = false
        return refresh(station)
    end

    -- la durée est celle d'une opération multipliée par la quantité
    local text = L('transfo_progress') .. (qty > 1 and (' (x%d)'):format(qty) or '')
    local completed = Tabac.menuProgress((action.duree or 4000) * qty, text)

    if completed then
        local done, outLabel, outQty = lib.callback.await('tabac:finTransfo', false, action.id)
        if done then
            notify(L('transfo_ok', outQty, outLabel), 'success')
        elseif outLabel == 'full' then
            notify(L('inventaire_plein'), 'error')
        else
            notify(L('erreur'), 'error')
        end
    else
        lib.callback.await('tabac:annulerTransfo', false)
        notify(L('transfo_annule'), 'info')
    end

    busy = false
    refresh(station)
end

local function openStation(station)
    if Tabac.isMenuOpen() or busy or GetGameTimer() < lastOpen then return end
    lastOpen = GetGameTimer() + 800

    CreateThread(function()
        Tabac.openMenu({
            mode        = 'action',
            keepOpen    = true,
            title       = Tabac.stripColors(station.blip.label),
            tag         = { title = station.menu.category, icon = station.menu.icon },
            category    = { title = station.menu.title, icon = station.menu.icon },
            buttonLabel = L('transfo_btn'),
            items       = buildItems(station),
            onSelect    = function(index, data)
                local action = station.actions[index]
                if action then transform(station, action, data.qty) end
            end
        })
    end)
end

local function setupStation(station, name, icon, label)
    Tabac.createBlip(station.pedPos, station.blip)

    Tabac.createPed(station, { {
        name     = name,
        icon     = icon,
        label    = label,
        distance = 2.5,
        onSelect = function() openStation(station) end
    } })
end

CreateThread(function()
    Tabac.waitLoaded()

    setupStation(Config.Transfo1,       'tabac_transfo1', 'fa-solid fa-industry', L('transfo1_target'))
    setupStation(Config.Transfo2Paquet, 'tabac_transfo2', 'fa-solid fa-cannabis', L('transfo2_target'))
end)
