local L, notify = Tabac.L, Tabac.notify
local cfg = Config.Vente

local busy = false
local lastOpen = 0

local function buildItems()
    local stock = lib.callback.await('tabac:infosItems', false, { cfg.item }) or {}
    local inv = stock[cfg.item] or { count = 0, label = L('vente_defaut') }

    return { {
        id       = cfg.item,
        title    = inv.label,
        icon     = 'fa-solid fa-box',
        image    = cfg.item,
        price    = cfg.prixUnite,
        stock    = inv.count,
        max      = cfg.maxParVente,
        disabled = inv.count < 1,
        reason   = inv.count < 1 and L('vente_aucun') or nil
    } }
end

local function refresh()
    if Tabac.isMenuOpen() then Tabac.updateMenu(buildItems()) end
end

local function sell(qty)
    if busy then return end

    qty = math.floor(tonumber(qty) or 0)
    if qty < 1 then return refresh() end

    busy = true
    local sold, total, err = lib.callback.await('tabac:vendre', false, qty)

    if err == 'manque' then
        notify(L('vente_aucun'), 'error')
    elseif err == 'pas_assez' then
        notify(L('vente_pas_assez'), 'error')
    elseif err then
        Tabac.notifyError(err)
    else
        notify(L('vente_ok', sold, total), 'success')
    end

    busy = false
    refresh()
end

local function openShop()
    if Tabac.isMenuOpen() or busy or GetGameTimer() < lastOpen then return end
    lastOpen = GetGameTimer() + 800

    CreateThread(function()
        Tabac.openMenu({
            mode     = 'shop',
            keepOpen = true,
            title    = L('vente_titre'),
            tag      = { title = L('vente_tag'), icon = 'fa-solid fa-cart-shopping' },
            category = { title = L('vente_categorie'), icon = 'fa-solid fa-basket-shopping' },
            items    = buildItems(),
            onSelect = function(_, data) sell(data.qty) end
        })
    end)
end

CreateThread(function()
    Tabac.waitLoaded()

    Tabac.createBlip(cfg.pedPos, cfg.blip)

    Tabac.createPed(cfg, { {
        name     = 'tabac_vendre',
        icon     = 'fa-solid fa-hand-holding-dollar',
        label    = L('vente_target'),
        distance = 2.5,
        onSelect = openShop
    } })
end)
