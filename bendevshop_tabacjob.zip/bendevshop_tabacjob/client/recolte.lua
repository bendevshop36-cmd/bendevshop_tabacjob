local L, notify = Tabac.L, Tabac.notify
local cfg = Config.Recolte

local ANIM_DICT = 'amb@world_human_gardener_plant@male@base'

local plants = {}       -- [id en base] = { data, entity, disponible, alpha, point, fadeToken }
local loadToken = 0
local harvesting = false
local blip

-- transparence d'une plante récoltée

local function applyAlpha(plant, alpha)
    local entity = plant.entity
    if not entity or not DoesEntityExist(entity) then return end

    if alpha >= 255 then
        ResetEntityAlpha(entity)
    else
        SetEntityAlpha(entity, alpha, false)
    end
end

local function fadePlant(plant, target)
    plant.fadeToken = (plant.fadeToken or 0) + 1
    local token = plant.fadeToken
    local from = plant.alpha

    if from == target or not plant.entity or not DoesEntityExist(plant.entity) then
        plant.alpha = target
        applyAlpha(plant, target)
        return
    end

    CreateThread(function()
        local startedAt = GetGameTimer()
        local duration = math.max(cfg.fadeTime, 1)

        -- un nouveau fondu change le token et arrête celui-ci
        while plant.fadeToken == token do
            local t = math.min((GetGameTimer() - startedAt) / duration, 1.0)
            plant.alpha = math.floor(from + (target - from) * t)
            applyAlpha(plant, plant.alpha)
            if t >= 1.0 then break end
            Wait(0)
        end
    end)
end

local function setAvailable(plant, available)
    if plant.disponible == available then return end
    plant.disponible = available
    fadePlant(plant, available and 255 or cfg.alphaRecoltee)
end

-- récolte

local function harvest(id)
    local plant = plants[id]
    if harvesting or not plant or not plant.disponible then return end
    if lib.progressActive() or Tabac.isMenuOpen() then return end

    harvesting = true

    -- le serveur réserve la plante pour éviter les doubles récoltes
    local ok, err = lib.callback.await('tabac:debutRecolte', false, id)
    if not ok then
        if err == 'deja_recoltee' then setAvailable(plant, false) end
        Tabac.notifyError(err)
        harvesting = false
        return
    end

    local ped = PlayerPedId()
    lib.requestAnimDict(ANIM_DICT)
    TaskTurnPedToFaceEntity(ped, plant.entity or ped, 400)
    Wait(400)
    TaskPlayAnim(ped, ANIM_DICT, 'base', 8.0, -8.0, -1, 1, 0, false, false, false)

    local pos = vector3(plant.data.x, plant.data.y, plant.data.z)
    local completed = Tabac.runProgress(cfg.duree, L('recolte_progress'), pos, 4.5)
    ClearPedTasks(ped)

    if completed then
        local done, reason = lib.callback.await('tabac:finRecolte', false, id)
        if done then
            setAvailable(plant, false)
            notify(L('recolte_success', cfg.quantite), 'success')
        else
            if reason == 'deja_recoltee' then setAvailable(plant, false) end
            Tabac.notifyError(reason)
        end
    else
        lib.callback.await('tabac:annulerRecolte', false, id)
        notify(L('annule'), 'info')
    end

    harvesting = false
end

-- apparition des plantes

local function despawnPlant(plant)
    if plant.entity and DoesEntityExist(plant.entity) then
        exports.ox_target:removeLocalEntity(plant.entity)
        DeleteEntity(plant.entity)
    end
    plant.entity = nil
end

local function spawnPlant(plant)
    if plant.entity and DoesEntityExist(plant.entity) then return end
    local data = plant.data

    local hash = Tabac.loadModel(data.model or cfg.model)
    if not hash then return end

    local obj = CreateObject(hash, data.x, data.y, data.z - 1.0, false, false, false)
    SetModelAsNoLongerNeeded(hash)
    if not obj or obj == 0 then return end

    SetEntityAsMissionEntity(obj, true, true)
    FreezeEntityPosition(obj, true)
    PlaceObjectOnGroundProperly(obj)

    plant.entity = obj
    applyAlpha(plant, plant.alpha)

    exports.ox_target:addLocalEntity(obj, {
        {
            name     = 'tabac_recolte_' .. data.id,
            icon     = 'fa-solid fa-leaf',
            label    = L('recolte_target'),
            distance = 2.0,
            canInteract = function()
                return plant.disponible and not harvesting and not Tabac.isMenuOpen() and not lib.progressActive()
            end,
            onSelect = function()
                CreateThread(function() harvest(data.id) end)
            end
        }
    })
end

local function clearPlants()
    for _, plant in pairs(plants) do
        plant.point:remove()
        despawnPlant(plant)
    end
    plants = {}
end

local function addPlant(data)
    local plant = {
        data       = data,
        disponible = not data.recoltee,
        alpha      = data.recoltee and cfg.alphaRecoltee or 255
    }
    plants[data.id] = plant

    plant.point = Tabac.stream(
        vector3(data.x, data.y, data.z),
        cfg.streamDistance,
        function() spawnPlant(plant) end,
        function() despawnPlant(plant) end
    )
end

-- le blip est posé sur cfg.blip.coords, ou au centre des plantes si absent
local function updateBlip()
    if blip and DoesBlipExist(blip) then RemoveBlip(blip) end
    blip = nil

    if not cfg.blip then return end

    local pos = cfg.blip.coords
    if not pos then
        local x, y, z, count = 0.0, 0.0, 0.0, 0
        for _, plant in pairs(plants) do
            x, y, z = x + plant.data.x, y + plant.data.y, z + plant.data.z
            count = count + 1
        end
        if count == 0 then return end
        pos = vector3(x / count, y / count, z / count)
    end

    blip = Tabac.createBlip(pos, cfg.blip)
end

local function loadPlants()
    loadToken = loadToken + 1
    local token = loadToken

    local list = lib.callback.await('tabac:chargerPlants', false)
    -- un autre chargement a démarré entre temps
    if token ~= loadToken or not list then return end

    clearPlants()
    for _, data in ipairs(list) do addPlant(data) end
    updateBlip()
end

CreateThread(function()
    Tabac.waitLoaded()
    Wait(1500)
    loadPlants()
end)

RegisterNetEvent('tabac:rechargerPlants', function()
    CreateThread(loadPlants)
end)

RegisterNetEvent('tabac:masquerPlante', function(id)
    local plant = plants[id]
    if plant then setAvailable(plant, false) end
end)

RegisterNetEvent('tabac:montrerPlante', function(id)
    local plant = plants[id]
    if plant then setAvailable(plant, true) end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end

    clearPlants()
    if blip and DoesBlipExist(blip) then RemoveBlip(blip) end
end)

-- commandes admin (la permission est vérifiée côté serveur)

RegisterCommand('addplant', function()
    CreateThread(function()
        local pos = GetEntityCoords(PlayerPedId())
        local id = lib.callback.await('tabac:ajouterPlant', false, pos.x, pos.y, pos.z)

        if id then
            notify(L('plant_added', id), 'success')
        else
            notify(L('plant_no_perm'), 'error')
        end
    end)
end, false)

RegisterCommand('delplant', function()
    CreateThread(function()
        local pos = GetEntityCoords(PlayerPedId())
        local closestId, closestDist = nil, cfg.distanceSuppr

        for id, plant in pairs(plants) do
            local dist = #(pos - vector3(plant.data.x, plant.data.y, plant.data.z))
            if dist < closestDist then closestId, closestDist = id, dist end
        end

        if not closestId then
            return notify(L('plant_not_found'), 'error')
        end

        local ok, err = lib.callback.await('tabac:supprimerPlant', false, closestId)
        if ok then
            notify(L('plant_removed', closestId), 'success')
        elseif err == 'not_found' then
            notify(L('plant_not_in_db'), 'error')
            loadPlants()
        else
            notify(L('plant_no_perm'), 'error')
        end
    end)
end, false)
