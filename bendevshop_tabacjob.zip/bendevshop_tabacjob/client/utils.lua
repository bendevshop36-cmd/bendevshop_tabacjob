local ESX = exports['es_extended']:getSharedObject()

Tabac = {}

local peds = {}

function Tabac.L(key, ...)
    local lang = Locales[Config.Locale] or Locales.fr
    local text = lang[key] or key
    if select('#', ...) == 0 then return text end

    local ok, result = pcall(string.format, text, ...)
    return ok and result or text
end

function Tabac.waitLoaded()
    while not ESX.IsPlayerLoaded() do Wait(250) end
end

-- enlève les codes couleur GTA (~y~, ~s~...) pour l'affichage dans le NUI
function Tabac.stripColors(text)
    return (text:gsub('~%a~', ''))
end

-- notifications

function Tabac.notify(msg, kind)
    kind = kind or 'info'

    if Config.Notify == 'esx' then
        ESX.ShowNotification(msg, kind)
    elseif Config.Notify == 'ox' then
        lib.notify({ description = msg, type = kind })
    else
        SendNUIMessage({ action = 'notify', message = msg, type = kind })
    end
end

-- code d'erreur renvoyé par le serveur -> clé de traduction
local errorKeys = {
    deja_recoltee = 'deja_recoltee',
    occupee       = 'plante_occupee',
    occupe        = 'occupe',
    full          = 'inventaire_plein',
    trop_loin     = 'trop_loin',
    quantite      = 'quantite_invalide'
}

function Tabac.notifyError(code)
    Tabac.notify(Tabac.L(errorKeys[code] or 'erreur'), 'error')
end

-- modèles

function Tabac.loadModel(model)
    local hash = type(model) == 'number' and model or joaat(model)
    if not IsModelInCdimage(hash) then return nil end

    RequestModel(hash)
    local timeout = GetGameTimer() + 5000
    while not HasModelLoaded(hash) do
        if GetGameTimer() > timeout then return nil end
        Wait(10)
    end
    return hash
end

-- blips

function Tabac.styleBlip(blip, cfg)
    SetBlipSprite(blip, cfg.sprite or 1)
    SetBlipColour(blip, cfg.color or 0)
    SetBlipScale(blip, cfg.scale or 0.8)
    SetBlipDisplay(blip, cfg.display or 4)
    SetBlipAsShortRange(blip, cfg.shortRange ~= false)

    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(cfg.label or '')
    EndTextCommandSetBlipName(blip)
end

-- cfg.coords permet de placer le blip ailleurs que sur le PNJ
function Tabac.createBlip(pos, cfg)
    if not cfg then return nil end

    local c = cfg.coords or pos
    local blip = AddBlipForCoord(c.x, c.y, c.z)
    Tabac.styleBlip(blip, cfg)
    return blip
end

-- marqueur et aide

function Tabac.drawMarker(pos)
    local m = Config.Marker
    local c = m.color

    local float = math.sin(GetGameTimer() / 1000.0 * m.floatSpeed) * m.floatAmplitude

    DrawMarker(m.icon, pos.x, pos.y, pos.z + m.iconHeight + float,
        0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
        m.iconSize.x, m.iconSize.y, m.iconSize.z,
        c.r, c.g, c.b, c.a,
        false, true, 2, false, nil, nil, false)
end

function Tabac.showHelp(text)
    BeginTextCommandDisplayHelp('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayHelp(0, false, true, -1)
end

-- apparition / disparition selon la distance (PNJ et plantes)
-- spawn et despawn sont appelés quand le joueur entre ou sort de la zone
function Tabac.stream(coords, distance, spawn, despawn)
    local inside, spawning = false, false

    return lib.points.new({
        coords   = coords,
        distance = distance,
        onEnter  = function()
            inside = true
            if spawning then return end

            spawning = true
            CreateThread(function()
                spawn()
                spawning = false
                -- le joueur est parti pendant le chargement du modèle
                if not inside then despawn() end
            end)
        end,
        onExit   = function()
            inside = false
            if not spawning then despawn() end
        end
    })
end

-- PNJ

function Tabac.createPed(cfg, targetOptions)
    local pos = cfg.pedPos
    local ped

    local function spawn()
        if ped and DoesEntityExist(ped) then return end

        local hash = Tabac.loadModel(cfg.pedModel)
        if not hash then return end

        local entity = CreatePed(4, hash, pos.x, pos.y, pos.z - 1.0, pos.w, false, false)
        SetModelAsNoLongerNeeded(hash)
        if not entity or entity == 0 then return end

        SetEntityAsMissionEntity(entity, true, true)
        SetEntityInvincible(entity, true)
        SetBlockingOfNonTemporaryEvents(entity, true)
        SetPedFleeAttributes(entity, 0, false)
        SetPedCanRagdoll(entity, false)
        FreezeEntityPosition(entity, true)

        ped = entity
        exports.ox_target:addLocalEntity(ped, targetOptions)
    end

    local function despawn()
        if ped and DoesEntityExist(ped) then
            exports.ox_target:removeLocalEntity(ped)
            DeleteEntity(ped)
        end
        ped = nil
    end

    peds[#peds + 1] = {
        despawn = despawn,
        point   = Tabac.stream(vector3(pos.x, pos.y, pos.z), Config.PedStreamDistance, spawn, despawn)
    }
end

-- barre de progression ox_lib, annulée si le joueur s'éloigne de pos

function Tabac.runProgress(duration, label, pos, maxDist)
    local finished = false

    if pos then
        CreateThread(function()
            while not finished do
                if #(GetEntityCoords(PlayerPedId()) - pos) > maxDist then
                    lib.cancelProgress()
                    return
                end
                Wait(200)
            end
        end)
    end

    local completed = lib.progressBar({
        duration     = duration,
        label        = label,
        useWhileDead = false,
        canCancel    = true,
        disable      = { move = true, car = true, combat = true }
    })

    finished = true
    return completed
end

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end

    SetNuiFocus(false, false)
    for _, entry in ipairs(peds) do
        entry.point:remove()
        entry.despawn()
    end
end)
