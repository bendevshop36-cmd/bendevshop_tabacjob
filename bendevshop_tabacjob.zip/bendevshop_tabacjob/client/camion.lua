local L, notify = Tabac.L, Tabac.notify
local cfg = Config.Camion

local truck = { entity = nil, blip = nil, returnBlip = nil, expireAt = 0 }
local busy = false
local lastPress = 0

local function hasTruck()
    return truck.entity ~= nil and DoesEntityExist(truck.entity)
end

local function clearTruck(deleteEntity)
    if truck.blip and DoesBlipExist(truck.blip) then RemoveBlip(truck.blip) end
    if truck.returnBlip and DoesBlipExist(truck.returnBlip) then RemoveBlip(truck.returnBlip) end

    if deleteEntity and truck.entity and DoesEntityExist(truck.entity) then
        local ped = PlayerPedId()
        if GetVehiclePedIsIn(ped, false) == truck.entity then
            TaskLeaveVehicle(ped, truck.entity, 16)
            Wait(300)
        end

        SetEntityAsMissionEntity(truck.entity, true, true)
        DeleteEntity(truck.entity)
        if DoesEntityExist(truck.entity) then DeleteVehicle(truck.entity) end
    end

    truck.entity, truck.blip, truck.returnBlip, truck.expireAt = nil, nil, nil, 0
end

-- location

local function attemptRent()
    if hasTruck() then
        return notify(L('camion_deja_loue'), 'error')
    end

    local sp = cfg.spawnPos
    if IsAnyVehicleNearPoint(sp.x, sp.y, sp.z, 3.0) then
        return notify(L('camion_zone_occupee'), 'error')
    end

    -- on charge le modèle avant de faire payer le joueur
    local hash = Tabac.loadModel(cfg.model)
    if not hash then
        return notify(L('erreur'), 'error')
    end

    local ok, seconds, plate = lib.callback.await('tabac:louerCamion', false)
    if not ok then
        SetModelAsNoLongerNeeded(hash)

        if seconds == 'pas_assez' then
            return notify(L('camion_pas_assez', cfg.prix), 'error')
        elseif seconds == 'deja_loue' then
            return notify(L('camion_deja_loue'), 'error')
        elseif seconds == 'trop_loin' then
            return notify(L('trop_loin'), 'error')
        end
        return notify(L('erreur'), 'error')
    end

    local veh = CreateVehicle(hash, sp.x, sp.y, sp.z, sp.w, true, false)
    SetModelAsNoLongerNeeded(hash)

    if not veh or veh == 0 or not DoesEntityExist(veh) then
        lib.callback.await('tabac:annulerLocation', false) -- remboursement
        return notify(L('erreur'), 'error')
    end

    SetEntityAsMissionEntity(veh, true, true)
    SetVehicleNumberPlateText(veh, plate)
    SetVehicleOnGroundProperly(veh)
    SetVehicleDoorsLocked(veh, 1)
    SetVehicleNeedsToBeHotwired(veh, false)
    SetVehicleHasBeenOwnedByPlayer(veh, true)
    SetVehicleEngineOn(veh, false, true, false)

    if cfg.onSpawn then pcall(cfg.onSpawn, veh, plate) end

    -- le serveur garde le netId pour supprimer le camion si le joueur se déconnecte
    lib.callback.await('tabac:enregistrerCamion', false, NetworkGetNetworkIdFromEntity(veh))

    truck.entity     = veh
    truck.blip       = AddBlipForEntity(veh)
    truck.returnBlip = Tabac.createBlip(cfg.markerRetour.pos, cfg.blipRetour)
    truck.expireAt   = GetGameTimer() + seconds * 1000
    Tabac.styleBlip(truck.blip, cfg.blipCamion)

    if cfg.warpInTruck then
        TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
    end

    notify(L('camion_loue_ok', math.floor(seconds / 60)), 'success')
end

local function attemptReturn()
    if not hasTruck() then return end

    local distance = #(GetEntityCoords(truck.entity) - cfg.markerRetour.pos)
    if distance > cfg.retourDistance then
        return notify(L('camion_pas_proche'), 'error')
    end

    local ok, err = lib.callback.await('tabac:retourCamion', false)
    if ok then
        clearTruck(true)
        return notify(L('camion_rendu_ok', cfg.prix), 'success')
    end

    if err == 'trop_loin' then
        notify(L('trop_loin'), 'error')
    elseif err == 'camion_loin' then
        notify(L('camion_pas_proche'), 'error')
    else
        notify(L('erreur'), 'error')
    end
end

-- le flag busy évite de lancer deux actions en même temps
local function runExclusive(action)
    if busy then return end
    busy = true
    local ok, err = pcall(action)
    busy = false

    if not ok then print(('[tabac] camion : %s'):format(err)) end
end

-- menus

local function openRentMenu()
    Tabac.openMenu({
        mode        = 'action',
        title       = L('camion_menu'),
        tag         = { title = L('camion_tag_louer'), icon = 'fa-solid fa-key' },
        category    = { title = L('camion_categorie'), icon = 'fa-solid fa-truck' },
        buttonLabel = L('camion_btn_louer'),
        items       = { {
            title   = L('camion_btn_louer'),
            desc    = L('camion_desc_louer'),
            icon    = 'fa-solid fa-truck',
            tag     = ('-%d$'):format(cfg.prix),
            details = {
                { label = L('camion_duree'),   value = L('minutes', math.floor(cfg.duree / 60000)) },
                { label = L('camion_caution'), value = L('camion_caution_val', cfg.prix) },
                { label = L('camion_retour'),  value = L('camion_retour_val'), state = 'ok' }
            }
        } },
        onSelect    = function() runExclusive(attemptRent) end
    })
end

local function openReturnMenu()
    local minutes = math.max(0, math.ceil((truck.expireAt - GetGameTimer()) / 60000))

    Tabac.openMenu({
        mode        = 'action',
        title       = L('camion_menu'),
        tag         = { title = L('camion_tag_retour'), icon = 'fa-solid fa-rotate-left' },
        category    = { title = L('camion_categorie'), icon = 'fa-solid fa-truck' },
        buttonLabel = L('camion_btn_rendre'),
        items       = { {
            title   = L('camion_btn_rendre'),
            desc    = L('camion_desc_rendre'),
            icon    = 'fa-solid fa-rotate-left',
            tag     = ('+%d$'):format(cfg.prix),
            details = {
                { label = L('camion_temps_reste'), value = L('minutes', minutes) },
                { label = L('camion_rembourse'),   value = ('%d$'):format(cfg.prix), state = 'ok' }
            }
        } },
        onSelect    = function() runExclusive(attemptReturn) end
    })
end

-- marqueur au point de location (ou de retour quand on a un camion)

CreateThread(function()
    Tabac.waitLoaded()

    while true do
        local sleep = 750
        local hasRental = hasTruck()
        local zone = hasRental and cfg.markerRetour or cfg.markerLouer
        local dist = #(GetEntityCoords(PlayerPedId()) - zone.pos)

        if dist < Config.Marker.drawDistance then
            sleep = 0
            Tabac.drawMarker(zone.pos)

            if dist < zone.radius and not Tabac.isMenuOpen() and not busy then
                Tabac.showHelp(L(hasRental and 'camion_help_rendre' or 'camion_help_louer'))

                if IsControlJustPressed(0, 38) and GetGameTimer() > lastPress then
                    lastPress = GetGameTimer() + 1000
                    if hasRental then openReturnMenu() else openRentMenu() end
                end
            end
        end

        Wait(sleep)
    end
end)

-- expiration de la location, camion détruit ou disparu

CreateThread(function()
    while true do
        Wait(2000)

        if truck.entity then
            if not DoesEntityExist(truck.entity) or IsEntityDead(truck.entity) then
                clearTruck(DoesEntityExist(truck.entity))
                lib.callback.await('tabac:libererCamion', false)
                notify(L('camion_perdu'), 'error')
            elseif GetGameTimer() > truck.expireAt then
                clearTruck(true)
                lib.callback.await('tabac:libererCamion', false)
                notify(L('camion_expire'), 'error')
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name == GetCurrentResourceName() then clearTruck(true) end
end)
