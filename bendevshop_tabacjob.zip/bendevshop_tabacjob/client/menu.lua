-- Menu NUI partagé par la location, la transformation et la vente.
--
-- Tabac.openMenu({
--     mode        = 'shop' | 'action',
--     title       = 'Titre',
--     tag         = { title = 'Vente', icon = 'fa-solid fa-cart-shopping' },
--     category    = { title = 'Boutique', icon = 'fa-solid fa-basket-shopping' },
--     buttonLabel = 'Lancer',
--     keepOpen    = true,        -- le menu reste ouvert après validation
--     items       = { ... },     -- voir BuildItems dans vente.lua / transformation.lua
--     onSelect    = function(index, data) end   -- data.qty = quantité choisie
-- })

local open, keepOpen = false, false
local onSelect
local progress

function Tabac.isMenuOpen()
    return open
end

local function uiStrings()
    local lang = Locales[Config.Locale] or Locales.fr
    return lang.ui
end

function Tabac.openMenu(data)
    if open then return end
    open, keepOpen, onSelect = true, data.keepOpen == true, data.onSelect

    SetNuiFocus(true, true)
    SendNUIMessage({
        action      = 'openMenu',
        mode        = data.mode or 'action',
        title       = data.title,
        tag         = data.tag,
        category    = data.category,
        buttonLabel = data.buttonLabel,
        keepOpen    = keepOpen,
        images      = Config.Images,
        lang        = uiStrings(),
        items       = data.items or {}
    })
end

-- met à jour les cartes sans fermer le menu
function Tabac.updateMenu(items)
    if not open then return end
    SendNUIMessage({ action = 'updateMenu', items = items or {} })
end

function Tabac.closeMenu()
    if not open then return end
    if progress then progress.cancelled = true end

    open, keepOpen, onSelect = false, false, nil
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'closeMenu' })
end

-- barre de progression dans le menu, renvoie true si elle est allée au bout
function Tabac.menuProgress(duration, label)
    if not open then return false end

    progress = { cancelled = false }
    SendNUIMessage({ action = 'progressStart', duration = duration, label = label })

    local finishAt = GetGameTimer() + duration
    local completed = true

    while GetGameTimer() < finishAt do
        if progress.cancelled or not open or IsEntityDead(PlayerPedId()) then
            completed = false
            break
        end
        Wait(50)
    end

    progress = nil
    if not completed and open then
        SendNUIMessage({ action = 'progressEnd' })
    end
    return completed
end

RegisterNUICallback('selectAction', function(data, cb)
    cb('ok')

    local callback = onSelect
    if not callback then return end

    if not keepOpen then
        open, onSelect = false, nil
        SetNuiFocus(false, false)
    end

    local index = tonumber(data and data.index)
    CreateThread(function() callback(index, data or {}) end)
end)

RegisterNUICallback('cancelProgress', function(_, cb)
    cb('ok')
    if progress then progress.cancelled = true end
end)

RegisterNUICallback('closeMenu', function(_, cb)
    cb('ok')
    if progress then progress.cancelled = true end

    open, keepOpen, onSelect = false, false, nil
    SetNuiFocus(false, false)
end)
